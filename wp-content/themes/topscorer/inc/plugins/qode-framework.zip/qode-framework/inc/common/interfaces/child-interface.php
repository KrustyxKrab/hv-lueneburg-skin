<?php

if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}

interface QodeFrameworkChildInterface {
	public function get_name();
}
