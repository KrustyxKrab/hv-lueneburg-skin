<?php

if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}

class QodeFrameworkOptionsFront extends QodeFrameworkOptions {

	public function __construct() {
		parent::__construct();
	}
}
