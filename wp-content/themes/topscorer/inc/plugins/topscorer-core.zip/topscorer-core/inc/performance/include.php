<?php

include_once TOPSCORER_CORE_INC_PATH . '/performance/dashboard/customizer/performance-customizer-options.php';
include_once TOPSCORER_CORE_INC_PATH . '/performance/helper.php';