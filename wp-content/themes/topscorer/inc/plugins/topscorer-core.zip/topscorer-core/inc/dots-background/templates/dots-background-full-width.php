<div class="qodef-m-background-dots-holder" <?php qode_framework_inline_style( $background_dots_content_style ); ?>>
<div class="qodef-m-background-dots-holder-full-width">
</div>
</div>