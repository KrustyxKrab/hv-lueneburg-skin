<?php

include_once TOPSCORER_CORE_INC_PATH . '/core-dashboard/rest/rest.php';