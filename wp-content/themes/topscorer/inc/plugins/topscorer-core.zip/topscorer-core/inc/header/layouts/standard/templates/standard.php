<?php
topscorer_core_get_header_logo_image();
topscorer_core_template_part( 'header', 'templates/parts/navigation' );
?>
<div class="qodef-widget-holder">
	<?php topscorer_core_get_header_widget_area(); ?>
</div>
