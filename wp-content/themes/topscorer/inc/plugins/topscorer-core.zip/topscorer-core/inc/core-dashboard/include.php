<?php

include_once TOPSCORER_CORE_INC_PATH . '/core-dashboard/core-dashboard.php';