<?php

include_once TOPSCORER_CORE_INC_PATH . '/spinner/layouts/predefined/helper.php';