<?php

include_once 'blog-list-loop.php';