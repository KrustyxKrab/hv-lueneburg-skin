<?php

include_once TOPSCORER_CORE_INC_PATH . '/spinner/layouts/pulse-circles/helper.php';