<div class="qodef-m-button">
	<?php echo TopScorerCoreButtonShortcode::call_shortcode( $button_params ); ?>
</div>