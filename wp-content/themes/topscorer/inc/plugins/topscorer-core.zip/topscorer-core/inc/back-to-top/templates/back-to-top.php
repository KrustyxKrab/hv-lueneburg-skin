<a id="qodef-back-to-top" href="#">
    <span class="qodef-back-to-top-icon">
        <span class="qodef-back-to-top-left"></span>
        <span class="qodef-back-to-top-right"></span>

    </span>
</a>