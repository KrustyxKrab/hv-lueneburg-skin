<?php

include_once TOPSCORER_CORE_CPT_PATH . '/post-types.php';