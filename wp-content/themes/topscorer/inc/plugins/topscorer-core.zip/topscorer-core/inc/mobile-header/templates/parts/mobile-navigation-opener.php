<a id="qodef-mobile-header-opener" href="#">
    <?php echo topscorer_core_get_svg ( 'sidearea' ); ?>
</a>