<?php

define( 'TOPSCORER_CORE_SPORTSPRESS_SHORTCODE_PREFIX', 'sportspress_shortcode_' );