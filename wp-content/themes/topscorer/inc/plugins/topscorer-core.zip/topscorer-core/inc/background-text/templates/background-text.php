<div class="qodef-m-background-text-holder qodef--has-appear" <?php qode_framework_inline_style( $background_text_content_style ); ?>>
    <span class="qodef-m-background-text" <?php qode_framework_inline_style( $background_text_style ); ?>>
	    <?php echo wp_kses_post( $text ); ?>
	</span>
</div>