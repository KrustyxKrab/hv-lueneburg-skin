<?php

include_once TOPSCORER_CORE_INC_PATH . '/sportspress/shortcodes/sportspress-player-gallery/sportspress-player-gallery.php';