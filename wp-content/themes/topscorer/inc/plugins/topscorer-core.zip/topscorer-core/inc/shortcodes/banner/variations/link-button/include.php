<?php

include_once TOPSCORER_CORE_SHORTCODES_PATH . '/banner/variations/link-button/helper.php';