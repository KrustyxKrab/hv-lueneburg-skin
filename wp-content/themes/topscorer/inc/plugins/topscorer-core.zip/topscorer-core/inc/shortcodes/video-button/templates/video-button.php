<div <?php qode_framework_class_attribute ( $holder_classes ); ?>>
    <?php topscorer_core_template_part ( 'shortcodes/video-button', 'templates/parts/image', '', $params ) ?>
    <?php topscorer_core_template_part ( 'shortcodes/video-button', 'templates/parts/button', '', $params ) ?>
</div>