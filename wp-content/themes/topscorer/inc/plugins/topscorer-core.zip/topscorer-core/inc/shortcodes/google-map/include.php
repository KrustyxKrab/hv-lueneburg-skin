<?php

include_once TOPSCORER_CORE_SHORTCODES_PATH . '/google-map/google-map.php';