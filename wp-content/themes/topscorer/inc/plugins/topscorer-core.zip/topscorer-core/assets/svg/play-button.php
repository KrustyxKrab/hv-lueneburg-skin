<?php
$svg = '<svg class="qodef-svg" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="15px" height="18px" viewBox="0 0 15 18" style="enable-background:new 0 0 15 18;" xml:space="preserve">
<g>
	<polygon  points="0,18 0,0 15,9"/>
</g>
</svg>';