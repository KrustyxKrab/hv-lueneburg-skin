<?php

$svg = '<svg class="qodef-svg" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="15px" height="15px" viewBox="0 0 15 15" style="enable-background:new 0 0 15 15;" xml:space="preserve">
<path fill="' . $color . '" d="M11.5,10.63c0.96-1.17,1.49-2.63,1.49-4.14C12.99,2.91,10.08,0,6.49,0S0,2.91,0,6.49
	c0,3.58,2.91,6.49,6.49,6.49c1.51,0,2.97-0.53,4.14-1.49l3.42,3.42L14.13,15L15,14.13L11.5,10.63z M6.49,11.76
	c-2.91,0-5.27-2.36-5.27-5.27s2.36-5.27,5.27-5.27s5.27,2.36,5.27,5.27S9.4,11.76,6.49,11.76z"/>
</svg>';