<?php
$svg='
<svg class="qodef-svg" version="1.1" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
	 width="23px" height="23px" viewBox="0 0 23 23" xml:space="preserve">
	<line x1="0.38" y1="0.38" x2="22.63" y2="22.63"/>
	<line x1="0.38" y1="0.38" x2="22.63" y2="22.63"/>
	<line x1="22.63" y1="0.38" x2="0.38" y2="22.63"/>
	<line x1="22.63" y1="0.38" x2="0.38" y2="22.63"/>
</svg>';


