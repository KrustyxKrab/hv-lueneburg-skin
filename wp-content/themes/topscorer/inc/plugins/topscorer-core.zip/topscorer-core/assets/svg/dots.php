<?php

$svg = '<svg version="1.1" class"qodef-svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="968px" height="536px" viewBox="0 0 968 536" style="enable-background:new 0 0 968 536;" xml:space="preserve">

<g class="st0">
	<circle cx="2" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="35.24" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="68.48" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="101.72" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="134.97" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="168.21" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="201.45" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="234.69" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="267.93" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="301.17" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="334.41" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="367.66" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="400.9" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="434.14" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="467.38" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="500.62" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="533.86" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="567.1" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="600.34" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="633.59" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="666.83" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="700.07" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="733.31" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="766.55" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="833.03" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="899.52" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="966" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="799.79" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="866.28" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="932.76" cy="2" r="2"/>
</g>
<g class="st0">
	<circle cx="2" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="2" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="2" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="2" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="2" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="2" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="2" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="2" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="2" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="2" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="2" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="2" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="2" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="2" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="2" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="2" cy="533.5" r="2"/>
</g>
<g class="st0">
	<circle cx="35.24" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="35.24" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="35.24" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="35.24" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="35.24" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="35.24" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="35.24" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="35.24" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="35.24" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="35.24" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="35.24" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="35.24" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="35.24" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="35.24" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="35.24" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="35.71" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="68.48" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="68.48" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="68.48" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="68.48" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="68.48" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="68.48" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="68.48" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="68.48" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="68.48" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="68.48" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="68.48" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="68.48" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="68.48" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="68.48" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="68.48" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="68.91" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="101.72" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="101.72" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="101.72" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="101.72" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="101.72" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="101.72" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="101.72" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="101.72" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="101.72" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="101.72" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="101.72" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="101.72" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="101.72" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="101.72" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="101.72" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="102.12" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="134.97" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="134.97" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="134.97" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="134.97" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="134.97" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="134.97" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="134.97" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="134.97" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="134.97" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="134.97" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="134.97" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="134.97" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="134.97" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="134.97" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="134.97" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="135.33" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="168.21" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="168.21" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="168.21" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="168.21" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="168.21" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="168.21" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="168.21" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="168.21" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="168.21" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="168.21" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="168.21" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="168.21" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="168.21" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="168.21" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="168.21" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="168.53" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="201.45" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="201.45" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="201.45" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="201.45" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="201.45" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="201.45" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="201.45" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="201.45" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="201.45" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="201.45" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="201.45" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="201.45" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="201.45" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="201.45" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="201.45" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="201.74" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="234.69" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="234.69" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="234.69" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="234.69" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="234.69" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="234.69" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="234.69" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="234.69" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="234.69" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="234.69" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="234.69" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="234.69" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="234.69" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="234.69" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="234.69" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="234.95" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="267.93" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="267.93" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="267.93" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="267.93" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="267.93" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="267.93" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="267.93" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="267.93" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="267.93" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="267.93" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="267.93" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="267.93" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="267.93" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="267.93" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="267.93" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="268.16" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="301.17" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="301.17" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="301.17" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="301.17" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="301.17" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="301.17" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="301.17" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="301.17" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="301.17" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="301.17" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="301.17" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="301.17" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="301.17" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="301.17" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="301.17" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="301.36" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="334.41" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="334.41" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="334.41" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="334.41" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="334.41" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="334.41" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="334.41" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="334.41" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="334.41" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="334.41" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="334.41" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="334.41" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="334.41" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="334.41" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="334.41" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="334.57" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="367.66" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="367.66" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="367.66" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="367.66" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="367.66" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="367.66" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="367.66" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="367.66" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="367.66" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="367.66" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="367.66" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="367.66" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="367.66" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="367.66" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="367.66" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="367.78" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="400.9" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="400.9" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="400.9" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="400.9" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="400.9" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="400.9" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="400.9" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="400.9" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="400.9" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="400.9" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="400.9" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="400.9" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="400.9" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="400.9" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="400.9" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="400.98" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="434.14" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="434.14" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="434.14" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="434.14" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="434.14" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="434.14" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="434.14" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="434.14" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="434.14" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="434.14" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="434.14" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="434.14" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="434.14" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="434.14" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="434.14" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="434.19" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="467.38" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="467.38" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="467.38" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="467.38" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="467.38" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="467.38" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="467.38" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="467.38" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="467.38" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="467.38" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="467.38" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="467.38" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="467.38" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="467.38" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="467.38" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="467.4" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="500.62" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="500.62" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="500.62" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="500.62" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="500.62" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="500.62" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="500.62" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="500.62" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="500.62" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="500.62" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="500.62" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="500.62" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="500.62" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="500.62" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="500.62" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="500.6" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="533.86" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="533.86" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="533.86" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="533.86" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="533.86" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="533.86" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="533.86" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="533.86" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="533.86" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="533.86" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="533.86" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="533.86" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="533.86" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="533.86" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="533.86" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="533.81" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="567.1" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="567.1" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="567.1" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="567.1" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="567.1" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="567.1" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="567.1" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="567.1" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="567.1" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="567.1" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="567.1" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="567.1" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="567.1" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="567.1" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="567.1" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="567.02" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="600.34" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="600.34" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="600.34" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="600.34" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="600.34" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="600.34" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="600.34" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="600.34" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="600.34" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="600.34" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="600.34" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="600.34" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="600.34" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="600.34" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="600.34" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="600.22" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="633.59" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="633.59" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="633.59" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="633.59" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="633.59" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="633.59" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="633.59" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="633.59" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="633.59" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="633.59" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="633.59" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="633.59" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="633.59" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="633.59" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="633.59" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="633.43" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="666.83" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="666.83" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="666.83" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="666.83" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="666.83" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="666.83" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="666.83" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="666.83" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="666.83" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="666.83" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="666.83" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="666.83" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="666.83" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="666.83" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="666.83" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="666.64" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="700.07" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="700.07" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="700.07" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="700.07" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="700.07" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="700.07" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="700.07" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="700.07" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="700.07" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="700.07" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="700.07" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="700.07" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="700.07" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="700.07" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="700.07" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="699.84" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="733.31" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="733.31" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="733.31" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="733.31" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="733.31" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="733.31" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="733.31" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="733.31" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="733.31" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="733.31" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="733.31" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="733.31" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="733.31" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="733.31" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="733.31" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="733.05" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="766.55" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="766.55" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="766.55" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="766.55" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="766.55" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="766.55" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="766.55" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="766.55" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="766.55" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="766.55" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="766.55" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="766.55" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="766.55" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="766.55" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="766.55" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="766.26" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="799.79" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="799.79" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="799.79" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="799.79" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="799.79" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="799.79" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="799.79" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="799.79" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="799.79" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="799.79" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="799.79" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="799.79" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="799.79" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="799.79" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="799.79" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="799.47" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="833.03" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="833.03" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="833.03" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="833.03" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="833.03" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="833.03" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="833.03" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="833.03" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="833.03" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="833.03" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="833.03" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="833.03" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="833.03" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="833.03" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="833.03" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="832.67" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="866.28" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="866.28" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="866.28" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="866.28" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="866.28" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="866.28" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="866.28" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="866.28" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="866.28" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="866.28" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="866.28" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="866.28" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="866.28" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="866.28" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="866.28" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="865.88" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="899.52" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="899.52" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="899.52" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="899.52" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="899.52" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="899.52" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="899.52" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="899.52" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="899.52" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="899.52" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="899.52" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="899.52" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="899.52" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="899.52" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="899.52" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="899.09" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="932.76" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="932.76" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="932.76" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="932.76" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="932.76" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="932.76" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="932.76" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="932.76" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="932.76" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="932.76" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="932.76" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="932.76" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="932.76" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="932.76" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="932.76" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="932.29" cy="534" r="2"/>
</g>
<g class="st0">
	<circle cx="966" cy="35.25" r="2"/>
</g>
<g class="st0">
	<circle cx="966" cy="68.5" r="2"/>
</g>
<g class="st0">
	<circle cx="966" cy="101.75" r="2"/>
</g>
<g class="st0">
	<circle cx="966" cy="135" r="2"/>
</g>
<g class="st0">
	<circle cx="966" cy="168.25" r="2"/>
</g>
<g class="st0">
	<circle cx="966" cy="201.5" r="2"/>
</g>
<g class="st0">
	<circle cx="966" cy="234.75" r="2"/>
</g>
<g class="st0">
	<circle cx="966" cy="268" r="2"/>
</g>
<g class="st0">
	<circle cx="966" cy="301.25" r="2"/>
</g>
<g class="st0">
	<circle cx="966" cy="334.5" r="2"/>
</g>
<g class="st0">
	<circle cx="966" cy="367.75" r="2"/>
</g>
<g class="st0">
	<circle cx="966" cy="401" r="2"/>
</g>
<g class="st0">
	<circle cx="966" cy="434.25" r="2"/>
</g>
<g class="st0">
	<circle cx="966" cy="467.5" r="2"/>
</g>
<g class="st0">
	<circle cx="966" cy="500.75" r="2"/>
</g>
<g class="st0">
	<circle cx="966" cy="534" r="2"/>
</g>
</svg>';